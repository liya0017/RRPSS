interface Item{
    String getName();
	double getPrice();
}
