class Drink extends MenuItem{
    
    Drink(String name, String description, double price){
        super(name, description, price);
    }
}
