class MainCourse extends MenuItem{
    
    MainCourse(String name, String description, double price){
        super(name, description, price);
    }
    
}
