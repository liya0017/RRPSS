enum Status {
	EMPTY,
	RESERVED,
	ASSIGNED
}
