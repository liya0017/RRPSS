class Dessert extends MenuItem{
    
    Dessert(String name, String description, double price){
        super(name, description, price);
    }
}
